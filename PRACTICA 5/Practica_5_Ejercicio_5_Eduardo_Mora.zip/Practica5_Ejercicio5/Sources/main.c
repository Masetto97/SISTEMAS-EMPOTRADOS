/* ###################################################################
 **     Filename    : main.c
 **     Project     : Practica5_Ejercicio5
 **     Processor   : MK64FN1M0VLQ12
 **     Version     : Driver 01.01
 **     Compiler    : GNU C Compiler
 **     Date/Time   : 2021-03-18, 11:58, # CodeGen: 0
 **     Abstract    :
 **         Main module.
 **         This module contains user's application code.
 **     Settings    :
 **     Contents    :
 **         No public methods
 **
 ** ###################################################################*/
/*!
 ** @file main.c
 ** @version 01.01
 ** @brief
 **         Main module.
 **         This module contains user's application code.
 */
/*!
 **  @addtogroup main_module main module documentation
 **  @{
 */
/* MODULE main */

/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "Pins1.h"
#include "ROJO.h"
#include "BitIoLdd1.h"
#include "KSDK1.h"
#include "MCUC1.h"
#include "UTIL1.h"
#include "VERDE.h"
#include "BitIoLdd2.h"
#include "FRTOS1.h"
#include "AS1.h"
#include "ASerialLdd1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "PDD_Includes.h"
#include "Init_Config.h"
/* User includes (#include below this line is not maintained by Processor Expert) */
#include "semphr.h"

xSemaphoreHandle sem1;
xQueueHandle colores;

static void Imprime(void *param) {
	char color[8];
	int i;
	for (;;) {
		if (xQueueReceive(colores, (void *) color,
				(portTickType) 0xFFFFFFFF) == pdTRUE) {
			/* Se ha recibido un dato. Se escribe por el puerto serie */
			for (i = 0; i < sizeof(color); i++)
				while (AS1_SendChar(color[i]) != ERR_OK) {
				}
			while (AS1_SendChar(10) != ERR_OK) {
			}
			while (AS1_SendChar(13) != ERR_OK) {
			}
		}
	}
}

static void LED_ROJO(void *param) {
	(void) param;
	char color[8] = "Rojo";
	for (;;) {
		FRTOS1_xQueueSendToFront(colores, color, (portTickType) 100);
		if (FRTOS1_xSemaphoreTake(sem1,(portTickType) 1000) == pdTRUE) {
			ROJO_PutVal(0);
			vTaskDelay(500 / portTICK_RATE_MS);
		}

		FRTOS1_xSemaphoreGive(sem1);
		ROJO_PutVal(1);
		vTaskDelay(500 / portTICK_RATE_MS);

	}
}

static void LED_VERDE(void *param) {
	(void) param;
	char color[8] = "Verde";
	for (;;) {
		FRTOS1_xQueueSendToFront(colores, color, (portTickType) 100);
		if (FRTOS1_xSemaphoreTake(sem1,(portTickType) 1000) == pdTRUE) {
			VERDE_PutVal(0);
			vTaskDelay(700 / portTICK_RATE_MS);
		}
		FRTOS1_xSemaphoreGive(sem1);
		VERDE_PutVal(1);
		vTaskDelay(700 / portTICK_RATE_MS);

	}
}

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
	/* Write your local variable definition here */

	/*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
	PE_low_level_init();
	/*** End of Processor Expert internal initialization.                    ***/

	sem1 = FRTOS1_xSemaphoreCreateBinary();
	FRTOS1_xSemaphoreGive(sem1);

	colores = FRTOS1_xQueueCreate(24, 8);

	if (xTaskCreate(LED_ROJO, /* funci�n de la tarea*/
	"rojo", /* nombre de la tarea para el kernel */
	configMINIMAL_STACK_SIZE, /* tama�o pila asociada a la tarea */
	(void*) NULL, /*puntero a los par�metros iniciales de la tarea */
	2,/* prioridad de la tarea, cuanto m�s bajo es el n�mero menor es la prioridad */
	NULL /* manejo de la tarea, NULL si ni se va a crear o destruir */
	) != pdPASS) { /* devuelve pdPASS si se ha creado la tarea */
	}

	if (xTaskCreate(LED_VERDE, /* funci�n de la tarea*/
	"verde", /* nombre de la tarea para el kernel */
	configMINIMAL_STACK_SIZE, /* tama�o pila asociada a la tarea */
	(void*) NULL, /*puntero a los par�metros iniciales de la tarea */
	3,/* prioridad de la tarea, cuanto m�s bajo es el n�mero menor es la prioridad */
	NULL /* manejo de la tarea, NULL si ni se va a crear o destruir */
	) != pdPASS) { /* devuelve pdPASS si se ha creado la tarea */
	}

	if (xTaskCreate(Imprime, /* funci�n de la tarea*/
	"imprimir", /* nombre de la tarea para el kernel */
	configMINIMAL_STACK_SIZE, /* tama�o pila asociada a la tarea */
	(void*) NULL, /*puntero a los par�metros iniciales de la tarea */
	1,/* prioridad de la tarea, cuanto m�s bajo es el n�mero menor es la prioridad */
	NULL /* manejo de la tarea, NULL si ni se va a crear o destruir */
	) != pdPASS) { /* devuelve pdPASS si se ha creado la tarea */
	}


	FRTOS1_vTaskStartScheduler();
	/*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
 ** @}
 */
/*
 ** ###################################################################
 **
 **     This file was created by Processor Expert 10.5 [05.21]
 **     for the Freescale Kinetis series of microcontrollers.
 **
 ** ###################################################################
 */
