/*
 * UART.h
 *
 *  Created on: 17/12/2014
 *      Author: Alejandro
 */

#ifndef UART_H_
#define UART_H_



#endif /* UART_H_ */

void USART_Write_Numero(unsigned short numero);
